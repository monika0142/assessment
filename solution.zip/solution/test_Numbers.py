from Numbers import Numbers
import unittest 

class NumbersTest(unittest.TestCase):
    
    def test_Positive1(self):
        obj = Numbers()
        result = obj.filterEvenNumbers([2,1,3,4,6,5,9,7,8,18,8,7,18])
        self.assertListEqual([2, 6, 8, 8, 18], result)
    
    def test_Positive2(self):
        obj = Numbers()
        result = obj.filterEvenNumbers([1,1,1,1,1,1,1,3,5,8,5,4])
        self.assertListEqual([], result)
    
    def test_Negative1(self):
        obj = Numbers()
        result = obj.filterEvenNumbers([3,2,5,8,5,4])
        self.assertListEqual([4], result)

if __name__ == '__main__': 
    unittest.main() 
